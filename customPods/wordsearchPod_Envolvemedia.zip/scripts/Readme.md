WordSearch Pod is based on code created by BunKat LLC <bill@bunkat.com> (https://github.com/bunkat/wordfind)

WordSearch Pod uses a version of table sorter from https://github.com/Mottie/tablesorter, to display the score/results